# OpenExplorer Doc Web Server Usage

For your usage, we provide the web server launch scripts.

Please select the corresponding launch script according to your OS:

- For Windows users, please execute the `start.bat`.

- For macOS or Linux users, please execute `start.sh`.
